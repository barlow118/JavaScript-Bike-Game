# JavaScript-Bike-Game
First attempt of making a simple JavaScript game.
